import * as ActionTypes from './ActionTypes';

export const cars = (state = { isLoading: true, errMess: null, cars: [] }, action) => {
  switch (action.type) {
    case ActionTypes.ADD_CARS:
      return { ...state, isLoading: false, errMess: null, cars: action.payload };
    case ActionTypes.CARS_LOADING:
      return { ...state, isLoading: true, errMess: null, cars: [] }
    case ActionTypes.CARS_FAILED:
      return { ...state, isLoading: false, errMess: action.payload };
    default:
      return state;
  }
};