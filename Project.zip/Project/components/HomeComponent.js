import React, { Component } from 'react';
import { View, Dimensions, Text } from 'react-native';
import { Card, Image } from 'react-native-elements';

import { baseUrl } from '../shared/baseUrl';
import Loading from './LoadingComponent';

import * as Animatable from 'react-native-animatable';
class RenderItem extends Component {
  render() {
    
      if (this.props.isLoading) {
        return (<Loading />);
      } else if (this.props.errMess) {
        return (<Text>{this.props.errMess}</Text>);
      } else {
        const item = this.props.item;
        if (item != null) {
    const item = this.props.item;
    if (item != null) {
      return (
        <Card>
          <Image source={{ uri: baseUrl + item.image }}  style={{ width: '100%', height: 100, flexGrow: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Card.FeaturedTitle>{item.name}</Card.FeaturedTitle>
            <Card.FeaturedSubtitle>{item.designation}</Card.FeaturedSubtitle>
          </Image>
          <Text style={{ margin: 10 }}>{item.description}</Text>
        </Card>
      );
    }
    return (<View />);
  }
}
  }
}
// redux
import { connect } from 'react-redux';
const mapStateToProps = (state) => {
  return {
    cars: state.cars,
    promotions: state.promotions,
    leaders: state.leaders
  }
};


class Home extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
    <View>
        <View>
        <Image source={require('../assets/background.png')} style={{ resizeMode: "cover",width: "100%",height: "100%" }}/> 
        <Animatable.View animation="fadeInDown" duration={2000} delay={1000}>
          <View style={{marginLeft:16,marginEnd:25,marginBottom:20,marginTop:5}}>
            <Text style={{textAlign: 'justify',color:'white'}}>
              Một chiếc xe mạnh chưa chắc đã mạnh nhưng một chiếc xe đẹp chắc chắn nó phải đẹp.
            </Text>
          </View>
        </Animatable.View>
        </View>
        
      </View>
)
  }
}
export default connect(mapStateToProps)(Home);