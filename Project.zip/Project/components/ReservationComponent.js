import React, { Component } from 'react';
import { StyleSheet, View, ScrollView, Text, Switch, Alert, } from 'react-native';
import { Icon, Button, Input } from 'react-native-elements';
import { Picker } from '@react-native-picker/picker';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import * as Animatable from 'react-native-animatable';
import { format } from 'date-fns';
import * as Notifications from 'expo-notifications';
import { getDatabase, ref, child, push } from 'firebase/database';



class Reservation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      guests: 'Supra',
      smoking: false,
      date: new Date(),
      showDatePicker: false,
      phonenumber:'',
      // showModal: false
    }
  }
  render() {
    return (
      <ScrollView>
        <Animatable.View animation="zoomIn" duration={2000} delay={1000}>
        <View style={styles.formRow}>
          <Text style={styles.formLabel}>Select Car:</Text>
          <Picker style={styles.formItem} selectedValue={this.state.guests} onValueChange={(value) => this.setState({ guests: value })}>
            <Picker.Item label='Toyota Supra' value='Toyota Supra' />
            <Picker.Item label='Toyota GR86' value='Toyota GR86' />
            <Picker.Item label='Toyota Camry' value='Toyota Camry' />
            <Picker.Item label='Toyota Corolla' value='Toyota Corolla' />
            <Picker.Item label='Toyota Tacoma' value='Toyota Tacoma' />
            <Picker.Item label='Nissan GTR' value='Nissan GTR' />
            <Picker.Item label='Subaru WRX' value='Subaru WRX' />
          </Picker>
        </View>
        <Input
          placeholder='PhoneNumber'
          leftIcon={{ name: 'phone', type: 'font-awesome' }}
          value={this.state.phonenumber}
          onChangeText={(phonenumber) => this.setState({ phonenumber })} />
        <View style={styles.formRow}>
          <Text style={styles.formLabel}>Test Drive?</Text>
          <Switch style={styles.formItem} value={this.state.smoking} onValueChange={(value) => this.setState({ smoking: value })} />
        </View>
        <View style={styles.formRow}>
          <Text style={styles.formLabel}>Date and Time</Text>
          <Icon name='schedule' size={39} onPress={() => this.setState({ showDatePicker: true })} />
          <Text style={{ margin: 10 }}>{format(this.state.date, 'dd/MM/yyyy - HH:mm')}</Text>
          <DateTimePickerModal mode='datetime' isVisible={this.state.showDatePicker}
            onConfirm={(date) => this.setState({ date: date, showDatePicker: false })}
            onCancel={() => this.setState({ showDatePicker: false })} />
        </View>
        <View style={{flexDirection:'column'}}>
          <Button title='Book' buttonStyle={{backgroundColor:'#000000'}} onPress={() => this.handleReservation()} />
        </View>
        </Animatable.View>
      </ScrollView>
    );
  }
  handleReservation() {
    const dbRef = ref(getDatabase());
    Alert.alert(
      'Your Appointment',
      'Car: ' + this.state.guests + '\nTest Drive ' + this.state.smoking + '\nDate and Time: ' + this.state.date.toISOString(),
      [
        { text: 'Cancel', onPress: () => this.resetForm() },
        { text: 'OK', onPress: () => {
          this.presentLocalNotification(this.state.date);
          this.resetForm();
        }},
      ],
      { cancelable: false }
    );
    push(child(dbRef, 'Appointment/'), {
      car: this.state.guests,
      testdrive: this.state.smoking,
      date: this.state.date.toString(),
      phonenumber: this.state.phonenumber,
      // showDatePicker: this.state.showDatePicker,
    })
      .catch((error) => alert('Could not set data from firebase', error));
  }
  resetForm() {
    this.setState({
      guests: 1,
      smoking: false,
      date: new Date(),
      phonenumber:'',
      showDatePicker: false
    });
  }
  async presentLocalNotification(date) {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status === 'granted') {
      Notifications.setNotificationHandler({
        handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: true })
      });
      Notifications.scheduleNotificationAsync({
        content: {
          title: 'Your Appointment',
          body: 'Appointment for ' + date + ' requested',
          sound: true,
          vibrate: true
        },
        trigger: null
      });
    }
  }
}


export default Reservation;

const styles = StyleSheet.create({
  formRow: { alignItems: 'center', justifyContent: 'center', flex: 1, flexDirection: 'row', margin: 30 },
  formLabel: { fontSize: 20, flex: 0 },  
  formItem: { flex: 1 }
});